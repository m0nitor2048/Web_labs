import styled from 'styled-components'

export const HeaderSection = styled.div`
    display: inline-block;
`



export const hr = styled.h1`
    border: none;
    border-bottom: 1px solid #6f6f6f;
`
