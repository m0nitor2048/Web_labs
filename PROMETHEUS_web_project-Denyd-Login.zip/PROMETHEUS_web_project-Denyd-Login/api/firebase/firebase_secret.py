config = {
    "apiKey": "AIzaSyChzmN5bRvo8nR1TPM0OArR9c-vMj2kzDQ",
    "authDomain": "ionkid-abd2f.firebaseapp.com",
    "databaseURL": "https://ionkid-abd2f.firebaseio.com",
    "projectId": "ionkid-abd2f",
    "storageBucket": "ionkid-abd2f.appspot.com",
    "messagingSenderId": "510693495451",
    "appId": "1:510693495451:web:f0ca5734a7c610e4bf2c3e"
}