import styled from 'styled-components';

export const Footer = styled.div`
    display: flex;
    margin-top: 20px;
    justify-content: space-between;
`